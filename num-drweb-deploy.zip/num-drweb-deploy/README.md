# NumDraw 배포 가이드

## 🚀 설치 및 실행

### 요구사항
- **웹브라우저**: Chrome 또는 Edge (File System Access API 지원)
- **OS**: Windows, macOS, Linux

### 실행 방법

#### 방법 1: 직접 열기 (가장 간단)
1. `index.html` 파일을 더블클릭
2. 웹브라우저에서 자동으로 열림

#### 방법 2: 웹서버에서 실행
```bash
# Python 3 사용
python -m http.server 8000

# 또는 Python 2
python -m SimpleHTTPServer 8000

# Node.js (http-server 설치 필요)
npx http-server
```

웹브라우저에서 `http://localhost:8000` 접속

---

## 📂 폴더 구조

```
num-drweb-deploy/
├── index.html           # 메인 페이지
├── css/
│   └── style.css        # 스타일시트
├── js/
│   ├── app.js           # 진입점
│   ├── annotation.js    # 넘버링 데이터
│   ├── canvas.js        # 도면 렌더링
│   ├── sidebar.js       # UI 사이드바
│   ├── fileManager.js   # 파일 관리
│   ├── pageManager.js   # 페이지 관리
│   ├── titleBlock.js    # 도곽 기능
│   └── storageManager.js # 저장소 관리
└── lib/
    └── (PDF.js는 CDN에서 로드)
```

---

## ✨ 주요 기능

- ✅ PDF / 이미지 도면 불러오기
- ✅ 2클릭으로 지시선 + 번호 추가
- ✅ 도면 도곽 생성 및 설정
- ✅ 자동 저장 (LocalStorage + IndexedDB)
- ✅ 현장 사진 매칭
- ✅ PDF 내보내기

---

## 🎮 핵심 단축키

| 단축키 | 기능 |
|--------|------|
| **Q** | 직교모드 ON/OFF |
| **F5** | 도면 전체 화면 맞추기 |
| **Ctrl+Z** | 마지막 번호 되돌리기 |
| **ESC** | 현재 그리기 취소 |
| **마우스 휠** | 확대/축소 |
| **Alt + 드래그** | 화면 이동 |

---

## 📝 사용 흐름

```
1. 도면 불러오기 (PDF/이미지 드래그앤드롭)
2. 넘버링 작업 (지시점 클릭 → 번호 위치 클릭)
3. 도곽 설정 (프로젝트/도면명/축척 입력)
4. 사진 폴더 연결 (번호 자동 매칭)
5. PDF 저장 (도면 + 넘버링 + 도곽 합성)
```

---

## 🔧 설정

### 사이드바 설정
- **지시점 도구**: 화살표 / 점 선택
- **색상**: 카테고리별 지시선 색상 커스터마이징
- **접두어**: 1F, RF 등 번호 접두어 설정
- **시작 번호**: 넘버링 시작값 설정
- **배율**: 넘버링 크기 조정 (0.5× ~ 3.0×)

---

## 📞 문제 해결

### 사진 폴더를 선택할 수 없어요
→ Chrome 또는 Edge 브라우저를 사용하세요 (Firefox 미지원)

### PDF를 불러올 수 없어요
→ 인터넷 연결을 확인하세요 (PDF.js는 CDN에서 로드)
→ 또는 [offline 모드 설정](오프라인-가이드) 참고

### 데이터가 자동으로 저장되나요?
→ 네, 변경사항이 3초마다 자동 저장됩니다.

---

**마지막 업데이트**: 2026-05-04
**버전**: 3.0 (Phase 3-b 완료)
